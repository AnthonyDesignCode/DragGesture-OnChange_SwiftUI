//
//  ContentView.swift
//  DragGesture_OnChanged_SwiftUI
//
//  Created by AnthonyDesignCode.io on 04/05/2020.
//  Copyright © 2020 AnthonyDesignCode.io. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State private var circlePosition = CGPoint(x: 50, y: 50)
    
    @State private var circleLabel = "50,50"
    
    @GestureState private var isDragging = false
    
    var body: some View {
        VStack(spacing: 20) {
            Text("DragGesture_Updating")
                .font(.largeTitle)
            Text("Gesture")
                .foregroundColor(.gray)
            
            Text("Drag the Circle")
            Text("isDragging: \(isDragging.description)")
            
            Circle()
                .fill(isDragging ? Color.purple : Color.red)
                .frame(width: 100, height: 100)
                .opacity(0.8)
                .overlay(Text(circleLabel))
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                .position(circlePosition).gesture(DragGesture().onChanged({ value in
                    self.circlePosition = value.location
                    self.circleLabel = "\(Int(value.location.x)), \(Int(value.location.y)) "
                    
                }).updating($isDragging) {(value, state, transaction) in
                        state = true
                })
                .border(Color.green)
        }
        .font(.title)
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
