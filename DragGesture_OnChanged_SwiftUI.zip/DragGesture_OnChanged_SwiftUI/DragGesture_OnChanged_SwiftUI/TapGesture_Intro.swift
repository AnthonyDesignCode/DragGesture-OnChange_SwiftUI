//
//  TapGesture_Intro.swift
//  DragGesture_OnChanged_SwiftUI
//
//  Created by Immature Inc on 06/05/2020.
//  Copyright © 2020 AnthonyDesignCode.io. All rights reserved.
//

import SwiftUI

struct TapGesture_Intro: View {
    
    @State private var hasDoubleTapped = false
    @State private var hasTripleTapped = false
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Gestures").font(.largeTitle)
            Text("Tap Gesture").foregroundColor(.gray)
            
            Text("Double-tap to change the hare")
            
            Image(systemName: hasDoubleTapped ? "hare.fill" : "hare")
                .font(.system(size: 100))
                .padding()
                .foregroundColor(hasTripleTapped ? .orange : .blue)
                .onTapGesture(count: 3) {
                    self.hasTripleTapped.toggle()
            }
        }.font(.title)
    }
}

struct TapGesture_Intro_Previews: PreviewProvider {
    static var previews: some View {
        TapGesture_Intro()
    }
}
